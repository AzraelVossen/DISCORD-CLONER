import { BackupData } from './';

export interface BackupInfos {
    id: string;
    size: number;
    data: BackupData;
}
