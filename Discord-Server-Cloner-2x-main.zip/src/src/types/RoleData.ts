export interface RoleData {
    name: string;
    color: `#${string}`;
    hoist: boolean;
    permissions: string;
    mentionable: boolean;
    position: number;
    isEveryone: boolean;
}
